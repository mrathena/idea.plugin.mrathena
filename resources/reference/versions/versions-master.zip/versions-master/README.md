# Project Version Changer

----

Project version changer for maven project, make the version change so easy!

## install

---


    git clone https://github.com/zwjlpeng/versions.git
    cd versions
    open the `IntelliJ IDEA` development env
    click in order `IntelliJ IDEA` -> `Preferences` -> `Plugins` -> `Install plugins from disk` -> `select the version.jar`
    restart the `IntelliJ IDEA`
    finish

## the fllowing are some screeshots for the above

---

the step 1:


![screenshot 1](https://github.com/zwjlpeng/versions/blob/master/images/screen_1.png?raw=true)

the real image for preview
 

![screenshot 2](https://github.com/zwjlpeng/versions/blob/master/images/screen_2.png?raw=true)


![screenshot 3](https://github.com/zwjlpeng/versions/blob/master/images/screen_3.png?raw=true)


## 更新日志

---

1. 增加对pom中properties节点的支持, 以及idea插件中右键弹出菜单的可见性[只在顶层目录上可见] 2016.11.24


## Contributor

---

    194312815@qq.com